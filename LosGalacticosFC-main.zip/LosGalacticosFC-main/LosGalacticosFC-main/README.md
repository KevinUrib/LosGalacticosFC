# LosGalacticosFC
Repositorio orientado al diseño web para un equipo de fútbol aplicando tecnologías como HTML5, CSS3 y framework Bootstrap5
